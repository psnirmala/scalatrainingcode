package com.boa.training.isa

//Employee constructor has 5 fields out of which 3 are passed to constructor of Person
class Manager(name:String,gender:String,age:Int,empId:Int,designation:String,location:String) extends
Employee(name,gender,age,empId,designation){
  override  def printDetails()
  {
    super.printDetails()//invokes the printDetails method of Person class
    println("Location:"+location)
    
  }
  
  
}