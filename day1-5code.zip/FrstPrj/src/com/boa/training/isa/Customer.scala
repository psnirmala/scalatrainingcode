package com.boa.training.isa

class Customer(id:Int,name:String,email:String){
  def this(id:Int){//auxillary constructor
    this(id,"Unknown name","Unknown email")
  }
  
  def this(id:Int,name:String){//auxillary constructor
    this(id,name,"Unknown email")
  }
  
  def printDetails=println("Id:"+id+"\tName:"+name+"\tEmail:"+email)
  
  override def toString():String="Customer[Id:"+id+"\tName:"+name+"\tEmail:"+email+"]"
}