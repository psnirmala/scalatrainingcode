package com.boa.training.isa

class Person(name:String,gender:String,age:Int) {
  def printDetails()
  {
    println("Name:"+name+"\tGender:"+gender+"\tAge:"+age)
  }
  
 
}