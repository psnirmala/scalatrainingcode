package com.boa.training.isa

object InheritanceTest1 {
  def main(args: Array[String]): Unit = {
    val emp1=new Employee("Arvind","Male",45,1001,"Developer");
    emp1.printDetails();
    
    val emp2=new Employee("Priya","Female",25,1002,"Accountant");
    emp2.printDetails();
    
   val manager1=new Manager("Amar","Male",45,3211,"HR Manager","Bangalore")
   manager1.printDetails()
  }
}