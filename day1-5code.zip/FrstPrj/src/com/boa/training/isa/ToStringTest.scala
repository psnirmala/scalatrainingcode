package com.boa.training.isa

class X{
  override def toString():String="Object of type X"
}

object ToStringTest {
  def main(args: Array[String]): Unit = {
    val x1=new X
    println(x1)// equivalent to println(x1.toString())
    
    val c1=new Customer(1224,"Akash","akash@gmail.com")
    
    println(c1)
  }
}