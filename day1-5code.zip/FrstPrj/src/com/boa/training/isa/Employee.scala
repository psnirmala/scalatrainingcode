package com.boa.training.isa

//Employee constructor has 5 fields out of which 3 are passed to constructor of Person
class Employee(name:String,gender:String,age:Int,empId:Int,designation:String) extends
Person(name,gender,age){
  override  def printDetails()
  {
    super.printDetails()//invokes the printDetails method of Person class
    println("Employee Id:"+empId)
    println("Designation:"+designation)
    
  }
  
  
}