package com.boa.training.functional

object Second {
  def main(args: Array[String]): Unit = {
    
    val n1=compute(10,15,max)
    println(n1)
    val n2=compute(10,15,min)
    println(n2)
    
  }
  
  def max(a:Int,b:Int)=if(a>b) a else b
  def min(a:Int,b:Int)=if(a<b) a else b
  
  def compute(x:Int,y:Int,f:(Int,Int)=>Int):Int=x+y+f(x,y)
}