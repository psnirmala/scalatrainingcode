package com.boa.training.functional

object FuncReturningFunc2 {
  def main(args: Array[String]): Unit = {
    
   println(func1(10)("hello"))
   //is equivalent to
   
   val f=func1(10)
   val g=f("hello")
   println(g)
   
  }
  //func1 takes one argument of type Double and returns a function which takes a string
  //as an argument and returns an Int.
  def func1(a:Int):String=>Int={
    println("printing the argument "+a)
    
    x=>x.length()+a
  }
  
  
  
}