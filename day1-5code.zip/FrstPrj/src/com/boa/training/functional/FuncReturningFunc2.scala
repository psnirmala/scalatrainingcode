package com.boa.training.functional

object FuncReturningFunc {
  def main(args: Array[String]): Unit = {
    
   val f1=func1(12)
   println(f1("hello"))
   
  }
  //func1 takes one argument of type Double and returns a function which takes a string
  //as an argument and returns an Int.
  def func1(a:Double):String=>Int={
    println("printing the argument "+a)
    
    func2
  }
  
  def func2(s:String):Int=s.length()
}