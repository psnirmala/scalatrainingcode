package com.boa.training.functional

object Third {
  def main(args: Array[String]): Unit = {
    
    val sum=calculate(10,15,add)
    println(sum)
    val diff=calculate(10,15,subtract)
    println(diff)
    val product=calculate(10,15,multiply)
    println(product)
    
    val quotient=calculate(10,5,divide)
    println(quotient)
    
    val n=calculate(10,5,(x,y)=>x*x+y*y+25)
    println(n)
    
  }
  
  def add(a:Int,b:Int)=a+b
  def subtract(a:Int,b:Int)=a-b
  def multiply(a:Int,b:Int)=a*b
  def divide(a:Int,b:Int)=a/b
  
  def calculate(x:Int,y:Int,f:(Int,Int)=>Int):Int=f(x,y)
}