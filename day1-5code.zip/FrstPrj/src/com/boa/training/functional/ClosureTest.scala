package com.boa.training.functional

object ClosureTest {
  def sum(a:Int,b:Int):Int=>Int=c=>a+b+c
  def main(args: Array[String]): Unit = {
    val x=sum(10,5)
    
    
    println(x(20))
    println(x(30))
  }
}