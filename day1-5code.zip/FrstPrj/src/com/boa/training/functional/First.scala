package com.boa.training.functional

object First {
  def main(args: Array[String]): Unit = {
    println("Welcome");
  }
}