package com.boa.training.functional

object FuncReturningFunc3 {
  def main(args: Array[String]): Unit = {
    
   a()();
   
  }
  //func1 takes one argument of type Double and returns a function which takes a string
  //as an argument and returns an Int.
  def a():()=>Unit={
    
    println("within a")
   ()=>{
      println("within function returned by a")
    }
    
    
  }
  
  
}