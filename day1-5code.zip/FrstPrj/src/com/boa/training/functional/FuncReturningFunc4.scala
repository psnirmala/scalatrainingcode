package com.boa.training.functional

object FuncReturningFunc4 {
  def main(args: Array[String]): Unit = {
    
   a()()();// is equivalent to
   
   val f=a()
   val g=f()
   g()
   
  }
  //func1 takes one argument of type Double and returns a function which takes a string
  //as an argument and returns an Int.
  def a():()=>(()=>Unit)={//return type of a is a function which does not accept any argument and
    //returns another function which inturn does not accept any argument and does not
    //return anything
    
    println("within a")
   ()=>{
      println("within function returned by a")
      ()=>{
        println("within the third nested function")
      }
    }
    
    
  }
  
  
}