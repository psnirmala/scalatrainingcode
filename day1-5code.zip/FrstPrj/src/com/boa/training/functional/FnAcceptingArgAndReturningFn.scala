package com.boa.training.functional

object FnAcceptingArgAndReturningFn {
  
  def main(args: Array[String]): Unit = {
    func(x=>x*2,x=>x*3,6,8)(7)
  }
  
  def func(f:Int=>Int,g:Int=>Int,a:Int,b:Int):Int=>Unit={
    val t=f(a)+g(b) 
    r=>{
      println("value is "+(t+r))
    }
  }
}