package com.boa.training.functional

object NestedFunctionTest {
  def maxAndMin(a:Int,b:Int):Unit={
    def maxValue():Int=if(a>b) a else b
    def minValue():Int=if(a<b) a else b
    println("max:"+maxValue())
    println("min:"+minValue())
  }
  
  def main(args: Array[String]): Unit = {
    maxAndMin(10,20)
  }
}