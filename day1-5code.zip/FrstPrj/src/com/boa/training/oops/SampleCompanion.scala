package com.boa.training.oops

class SampleCompanion {
  private val i=10
}

object SampleCompanion{
  def print(s:SampleCompanion){
  println(s.i)
  }
}