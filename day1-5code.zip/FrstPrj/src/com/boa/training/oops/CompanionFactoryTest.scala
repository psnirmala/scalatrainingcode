package com.boa.training.oops

class K{
  
}

class L extends K{
  override def toString()="Object of type L";
}

class M extends L{
  override def toString()="Object of type M";
}

object K{
  def newInstance(t:String):K={
    if(t.equals("l")) new L()
    else new M()
  }
}

object CompanionFactoryTest {
  def main(args: Array[String]): Unit = {
    val k=K.newInstance("l")
    println(k)
    val m=K.newInstance("m")
    println(m)
  }
}