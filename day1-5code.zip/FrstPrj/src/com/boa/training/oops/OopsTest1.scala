package com.boa.training.oops


class Employee(id:Int,name:String,designation:String){
  def printDetails()={
    println("Id:"+id)
    println("Name:"+name)
    println("Designation:"+designation)
  }
  
}

object OopsTest1 {
  def main(args: Array[String]): Unit = {
    val emp1=new Employee(1001,"Arvind","Developer")
    val emp2=new Employee(1002,"Priya","Accountant")
    
    emp1.printDetails()
    emp2.printDetails()
  }
}