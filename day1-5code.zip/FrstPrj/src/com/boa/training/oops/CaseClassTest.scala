package com.boa.training.oops

case class Person(name:String,age:Int,gender:String){
  def printDetails=println("Name:"+name+"\tGender:"+gender+"\tAge:"+age)
}

object CaseClassTest {
  def main(args: Array[String]): Unit = {
    val p1=Person("Arvind",25,"Male")
    val p2=Person("Suresh",21,"Male")
    val p3=Person("Priya",22,"Female")
    
    
    p1.printDetails
    p2.printDetails
    p3.printDetails
  }
}