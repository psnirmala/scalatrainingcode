package com.boa.training.oops




class X{
  def test(){
    println("test method of X")
  }
}
object OopsTest2 {
  def main(args: Array[String]): Unit = {
  val x1=new X
  x1.test
  }
}