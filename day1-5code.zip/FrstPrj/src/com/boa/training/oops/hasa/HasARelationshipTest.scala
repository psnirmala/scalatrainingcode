package com.boa.training.oops.hasa

object HasARelationshipTest {
  def main(args: Array[String]): Unit = {
    val e1=new Employee(1001,"Rajiv","Developer",new Address("Punjakutta","Hyderabad"))
    val e2=new Employee(1002,"Amar","Accountant",new Address("Anna Nagar","Chennai"))
    
    
    e1.printDetails
    e2.printDetails
    
    val e3=new Employee(1003,"Surya","Architect")
    e3.printDetails
  }
}