package com.boa.training.oops.hasa

class Employee(id:Int,name:String,designation:String) {
  var address:Address=null
  
  def this(id:Int,name:String,designation:String,address:Address)
  {
    this(id,name,designation)
    //this.address denotes the data member address and address denotes the local variable(parameter)
    this.address=address
  }
  
  def printDetails={
    println("Id:"+id)
    println("Name:"+id)
    println("Designation:"+designation)
    if(address!=null){
      address.printDetails()
    }
  }
}