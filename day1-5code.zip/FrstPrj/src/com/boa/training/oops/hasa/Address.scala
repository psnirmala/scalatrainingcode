package com.boa.training.oops.hasa

class Address(location:String,city:String) {
  def printDetails(){
    println("Location:"+location)
    println("City:"+city)
  }
}