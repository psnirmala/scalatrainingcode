package com.boa.training.oops

object CaseClassTest2 {
  def main(args: Array[String]): Unit = {
    
    val persons=Array( Person("Surya",34,"Male"),
        Person("Kumar",24,"Male"),
        Person("Ramya",21,"Female"))
        
      persons.foreach(p=>p.printDetails)  
        
  }
}