package com.boa.training.oops

object CustomerTest {
  def main(args: Array[String]): Unit = {
    val cust1=new Customer(1001)
    
    val cust2=new Customer(1002,"Rajesh")
    
    
    val cust3=new Customer(1003,"Deva","deva@gmail.com")
    
    cust1.printDetails
    cust2.printDetails
    
    cust3.printDetails
  }
}