package com.boa.training.oops

object A{
  def test(){//similar to a static method
    println("test method of Object A")
  }
}
object B{
  def test(){//similar to a static method
    println("test method of Object B")
  }
  
  def add(a:Int,b:Int)=a+b
}

object SingletonTest {
  def main(args: Array[String]): Unit = {
    A.test()
    B.test()
    val c=B.add(20, 40)
    println(c)
  }
}