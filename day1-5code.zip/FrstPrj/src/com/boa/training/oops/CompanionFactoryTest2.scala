package com.boa.training.oops

class Flyer{
  
}

class Aeroplane extends Flyer{
  override def toString()="Aeroplane";
}

class Bird extends Flyer{
  override def toString()="Bird";
}

object Flyer{
  def newInstance(t:String):Flyer={
    if(t.equals("Aero")) new Aeroplane()
    else new Bird()
  }
}

object CompanionFactoryTest2 {
  def main(args: Array[String]): Unit = {
    val a=Flyer.newInstance("Aero")
    println(a)
    val b=Flyer.newInstance("Bird")
    println(b)
  }
}