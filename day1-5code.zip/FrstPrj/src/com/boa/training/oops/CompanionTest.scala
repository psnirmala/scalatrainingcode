package com.boa.training.oops

object CompanionTest {
  def main(args: Array[String]): Unit = {
    val comp=new SampleCompanion()
    SampleCompanion.print(comp)
  }
}