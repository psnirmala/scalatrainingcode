package com.boa.training.akka

import akka.actor.ActorSystem
import akka.actor.Props

object ActorTest {
  def main(args: Array[String]): Unit = {
    val actorSystem=ActorSystem("TestActorSystem")
    val actor1=actorSystem.actorOf(Props[SampleActor])
    val actor2=actorSystem.actorOf(Props[SampleActor])
    
    actor1 ! "Sample message"
    actor2 ! 34
    
  }
}