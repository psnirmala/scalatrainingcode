package com.boa.training.akka

import akka.actor.Actor

class SampleActor extends Actor{
  def receive={
    case msg:String=>println(msg+" received from "+self.path)
    case _=>println("unknown type message from "+self.path)
  }
}