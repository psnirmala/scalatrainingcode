package com.boa.training.oops

object AppTest extends App {
  println("Testing App")
}