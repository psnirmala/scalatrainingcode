package com.boa.training.oops

abstract class Animal{
  def color():String
  def lifeCycleTime():Int
  
  def describe(){
    println("Color: "+color())
    println("Life Cycle Time:"+lifeCycleTime()+" years")
  }
}

class Elephant extends Animal{
  override def color="Black"
  override def lifeCycleTime()=50
  
}

class Rabbit extends Animal{
  override def color="White"
  override def lifeCycleTime()=20
  
}
object AbstractTest {
  def main(args: Array[String]): Unit = {
    
    val a:Animal=new Elephant
    a.describe()
    val a1=new Rabbit
    a1.describe()
    
  }
  
}