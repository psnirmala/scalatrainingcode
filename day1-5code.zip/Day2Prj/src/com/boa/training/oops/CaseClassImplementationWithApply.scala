package com.boa.training.oops

class X{
  override def toString="Object of type X"
}

object X{
  def apply():X=new X()
}


object CaseClassImplementationWithApply {
  def main(args: Array[String]): Unit = {
    val x1= X()
    println(x1)
    println(X())
    
   
    
  }
}