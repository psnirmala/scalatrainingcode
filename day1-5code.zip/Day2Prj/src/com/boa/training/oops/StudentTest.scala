package com.boa.training.oops

object StudentTest {
  def main(args: Array[String]): Unit = {
    val s1=Student(1223)
    s1.printDetails()
    
    val s2=Student(23211,"Amar","Male",16)
    s2.printDetails()
  }
}