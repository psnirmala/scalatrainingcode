package com.boa.training.oops

object A{
  def apply(s:String)="Testing string "+s
  def apply()="Testing without args"
  def apply(a:Int)="Testing int "+a
}

object ApplyTest2 {
  def main(args: Array[String]): Unit = {
    println(A("Sample"))
    println(A())
    println(A(25))
  }
}