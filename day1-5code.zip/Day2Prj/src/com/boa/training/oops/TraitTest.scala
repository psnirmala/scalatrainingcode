package com.boa.training.oops

trait Feedable{
  def eat()
}

trait Flyer{
  def fly()
}

trait Noisable{
  def makeSound()
}

class Aeroplane extends Flyer with Noisable{
   def fly()=println("Aeroplane flying")
   def makeSound()=println("Aeroplane making sound")
}
class Bird extends Flyer with Feedable with Noisable{
   def eat()=println("Bird eating")
   def fly()=println("Bird flying")
   def makeSound()=println("Bird making sound")
}


object TraitTest {
  def main(args: Array[String]): Unit = {
    val a=new Aeroplane
    a.fly()
    
    val b=new Bird
    b.eat()
    b.fly()
    
    println(a.isInstanceOf[Flyer])
    println(a.isInstanceOf[Feedable])
    
    
    println(b.isInstanceOf[Flyer])
    println(b.isInstanceOf[Feedable])
    
    println(a.isInstanceOf[Noisable])
    println(b.isInstanceOf[Noisable])
  }
}