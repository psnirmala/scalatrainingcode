package com.boa.training.oops

class Student(rollno:Int,name:String,gender:String,age:Int) extends
Person(name,gender,age){
  
  def this(rollno:Int)
  {
    this(rollno,"Unknown","Unknown",12)
  }
  override def printDetails()={
    super.printDetails()
    println("Rollno:"+age)
  }
  
}

object Student{
  def apply(rollno:Int,name:String,gender:String,age:Int):Student=new Student(rollno,name,gender,age)
  def apply(rollno:Int)=new Student(rollno)
}