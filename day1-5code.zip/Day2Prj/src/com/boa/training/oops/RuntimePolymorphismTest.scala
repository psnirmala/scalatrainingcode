package com.boa.training.oops

class E{
  def test(){
    println("test method of E")
  }
}
class F extends E{
  override def test(){
    println("test method of F")
  }
}

class G extends F{
  override def test(){
    println("test method of G")
  }
}

object RuntimePolymorphismTest {
  def testing(e:E){
    if(e.isInstanceOf[G]){
      println("holding object of type G")
    }
    else if(e.isInstanceOf[F]){
      println("holding object of type F")
    }
    else if(e.isInstanceOf[E]){
      println("holding object of type E")
    }
    e.test()
    
    
  }
  
  def main(args: Array[String]): Unit = {
    testing(new E())
    testing(new F())
    testing(new G())
    
    val a=new F()
    val b=new G()
    val c=new E()
    
    println(a.isInstanceOf[AnyRef])
    println(b.isInstanceOf[AnyRef])
    println(c.isInstanceOf[AnyRef])
  }
}