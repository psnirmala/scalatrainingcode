package com.boa.training.oops

class Person(name:String,gender:String,age:Int) {
  def printDetails()={
    println("Name:"+name+"\tGender:"+gender+"\tAge:"+age)
  }
  
}