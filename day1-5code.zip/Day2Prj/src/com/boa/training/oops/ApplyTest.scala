package com.boa.training.oops

object Greeting{
  def apply(name:String)="Welcome "+name
}

object ApplyTest {
  def main(args: Array[String]): Unit = {
    println(Greeting.apply("Arun"));
    
    println(Greeting("Arun"))
  }
}