package com.boa.training.oops

class R{
  def test()=println("method without any argument")
  
  def test(a:Int)=println("method with one int argument "+a)
  def test(a:Int,b:Double)=println("method with one int "+a+" one double "+b+" argument ")
  
  def test(a:Int,b:Int)=println("method with two int arguments "+a+","+b)
}

object MethodOverloadingTest {
  def main(args: Array[String]): Unit = {
    val a=new R()
    a.test()
    a.test(10,20)
    a.test(10,34.22)
    a.test(70)
  }
  
}