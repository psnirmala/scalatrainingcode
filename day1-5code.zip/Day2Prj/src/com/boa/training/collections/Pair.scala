package com.boa.training.collections

class Pair(val first:Int,val second:Int) {
   override def hashCode():Int={
      println("invoking the hashCode of "+this)
    return first+second
  }
  
  override def equals(obj:Any):Boolean={
    println("invoking the equals of "+this)
    var eq=false;
    val p=obj.asInstanceOf[Pair]
    if(first==p.first &&second==p.second) eq=true;
    eq
  }
  override def toString:String="Pair[first="+first+",second="+second+"]";
}