package com.boa.training.collections

object ArrayTest4 extends App{
  val array:Array[Person]=Array(new Person("Arvind","Male",23),new Person("Priya","Female",22),
      new Person("Suresh","Male",19),Customer("Surya","Male",34,1001))
 
  
  array.foreach(p=>p.printDetails())
  
}