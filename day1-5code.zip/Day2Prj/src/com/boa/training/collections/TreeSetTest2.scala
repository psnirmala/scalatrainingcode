package com.boa.training.collections

import scala.collection.mutable.TreeSet

object TreeSetTest2 {
  def main(args: Array[String]): Unit = {
    val set:TreeSet[NumberPair]=TreeSet()
    set+=new NumberPair(23,33)
    set+=new NumberPair(23,11)
    set+=new NumberPair(11,56)
    set+=new NumberPair(78,22)
    println(set)
    
    
   
  }
}