package com.boa.training.collections

import scala.collection.mutable.TreeSet

object TreeSetTest1 {
  def main(args: Array[String]): Unit = {
    val set:TreeSet[Int]=TreeSet()
    set+=10
    set+=11
    set+=20
    set+=10
    println(set)
    
    
    val set1:TreeSet[String]=TreeSet()
    set1+="apple"
    set1+="orange"
    set1+="apple"
    set1+="mango"
    set1+="grape"
    println(set1)
  }
}