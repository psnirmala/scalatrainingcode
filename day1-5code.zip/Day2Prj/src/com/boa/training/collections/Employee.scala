package com.boa.training.collections

class Employee(val id:Int,val name:String,val designation:String) {
  override def toString():String="Employee[id="+id+",name="+name+",designation="+designation+"]"
  
  override def hashCode():Int={
    println("invoking the hashcode of "+this)
    return id;
  }
  
  override def equals(obj:Any):Boolean={
    println("invoking the equals of "+this)
    var eq=false;
    val emp=obj.asInstanceOf[Employee]
    if(id==emp.id &&name==emp.name&&designation==emp.designation) eq=true;
    eq
  }
  
}