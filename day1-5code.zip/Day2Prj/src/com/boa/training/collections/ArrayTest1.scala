package com.boa.training.collections

object ArrayTest1 extends App{
  val array=Array.ofDim[Int](5)
  array(2)=45
  array(4)=56
  
  array.foreach(x=>println(x))
  
  array.foreach(println)
  
  
  
}