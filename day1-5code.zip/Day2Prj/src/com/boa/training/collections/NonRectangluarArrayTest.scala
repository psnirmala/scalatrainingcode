package com.boa.training.collections

object NonRectangluarArrayTest extends App {
  
  var a=Array(Array(23,55),Array(67),Array(23,77,12,55),Array(2,5,12))
  //a is a two dimensional arry,elt is a one dimensional array and b is an int
  a.foreach(elt=>{
    println()
    elt.foreach(b=>print(b+"\t"))
  });
}