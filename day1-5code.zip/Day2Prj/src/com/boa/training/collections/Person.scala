package com.boa.training.collections

 class Person(name:String,gender:String,age:Int) {
  def printDetails()
  {
    println("Name:"+name+"\tGender:"+gender+"\tAge:"+age)
  }
  
 
}

case class Customer(name:String,gender:String,age:Int,customerId:Int) extends Person(name,gender,age){
  override def printDetails()
  {
    super.printDetails()
    println("Customer Id:"+customerId)
  }
}