package com.boa.training.collections

import scala.collection.mutable.Set

object SetTest extends App{
  
  val set:Set[Employee]=Set()
  set += new Employee(1111,"Deva","Developer")
  set += new Employee(1111,"Deva","Developer")
  set += new Employee(1112,"Arvind","Accountant")
  set.foreach(e=>println(e))
}