package com.boa.training.collections

class NumberPair(val first:Int,val second:Int) extends Ordered[NumberPair] {
  
  override def toString:String="Pair[first="+first+",second="+second+"]"
  
  def compare(that:NumberPair):Int=
  {
    var comp=0
    println("comparing "+this+" with "+that)
    if(first<that.first) comp= -1
    else if(first>that.first) comp=1
    comp
  }
  
}