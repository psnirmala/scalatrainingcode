package com.boa.training.collections

import scala.collection.mutable.Set

object SetTest2 extends App{
  
  val set:Set[Pair]=Set()
  set += new Pair(23,55)
  set += new Pair(34,11)
  set += new Pair(23,55)
  set.foreach(p=>println(p))
}