package com.boa.training.collections

import scala.collection.mutable.TreeSet

object TreeSetTest3 {
  def main(args: Array[String]): Unit = {
    val set:TreeSet[Int]=TreeSet()((first,second)=>second.compareTo(first));
    set+=10
    set+=11
    set+=20
    set+=10
    println(set)
    
    
    
  }
}