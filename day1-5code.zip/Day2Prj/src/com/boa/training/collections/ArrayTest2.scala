package com.boa.training.collections

object ArrayTest2 extends App{
  val array=Array("apple","orange","mango")
 
  
  array.foreach(println)
  array.foreach(displayInUpperCase)
  
  
  def displayInUpperCase(s:String):Unit={
    println(s.toUpperCase())
  }
}