package domain
import play.api.libs.json._
case class Employee(id:Int,name:String,designation:String)
object Employee {
  implicit object EmployeeFormat extends Format[Employee]{
    
    //deserialization (json to scala)
    def reads(json:JsValue):JsResult[Employee]={
      val id=(json \ "id").as[Int]
      val name=(json \ "name").as[String]
      val designation=(json \ "designation").as[String]
      JsSuccess(Employee(id,name,designation))
    }
    
    //serialization (scala to json)
    
    def writes(emp:Employee):JsValue={
      val data=Seq("id"->JsNumber(emp.id),"name"->JsString(emp.name),
          "designation"->JsString(emp.designation))
          JsObject(data)
    }
    
    
  }
}