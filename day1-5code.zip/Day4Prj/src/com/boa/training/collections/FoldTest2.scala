package com.boa.training.collections

object FoldTest2 {
  def main(args: Array[String]): Unit = {
    val list=List(5,2,10,2)
    println(list.reduce(_+_))
    println(list.reduce((x,y)=>x+y))
    
    println(list.fold(100)(_+_))
    
    println(list.fold(100)((x,y)=>{
      println("adding "+x+" with "+y)
      x+y
    }))
    println("using fold right")
    println(list.foldRight(100)((x,y)=>{
      println("adding "+x+" with "+y)
      x+y
    }))
    println(list.scan(100)((x,y)=>{
      println("adding "+x+" with "+y)
      x+y
    }))
  }
}