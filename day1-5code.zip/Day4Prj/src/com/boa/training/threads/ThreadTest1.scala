package com.boa.training.threads

class XThread extends Thread{
  override def run()
  {
    for(i<-1 to 100){
      println("Inside thread "+Thread.currentThread().getName+" "+i)
    }
  }
}
class YThread extends Thread{
  override def run()
  {
    var x=1;
    for(i<-1 to 50){
      x=x+10
      println("Inside thread "+Thread.currentThread().getName+" "+i+" "+x)
    }
  }
}
object ThreadTest1 {
  def main(args: Array[String]): Unit = {
    val thread1=new XThread()
    thread1.setName("first")
    thread1.start
    val thread2=new YThread()
    thread2.setName("second")
    thread2.start
    
  }
}