package com.boa.training.match1

case class Person(name:String,age:Int){
  override def toString="Person[Name:"+name+",Age:"+age+"]"
  
}
object MatchTest2 {
  
  def getMessage(p:Person):String={
    val msg=p match {
      case Person("Arvind",25)=>"Welcome Arvind"
      case Person("Sujay",35)=>"Hi Sujay"
      case _=>p.toString()  
    }
    msg
  }
  
  def main(args: Array[String]): Unit = {
    val p1= Person("Sujay",35)
    println(getMessage(p1))
    println(getMessage(Person("Deva",22)))
  }
}