package com.boa.training.match1

object MatchTest1 {
  def main(args: Array[String]): Unit = {
    println(colorToNumber("Red"))
    println(colorToNumber("Blue"))
    println(colorToNumber("Yellow"))
  }
  
  def colorToNumber(color:String):Int={
    val num=color match{
      case "Red"=>1
      case "Green"=>2
      case "Blue"=>3
      
      case _=>0
    }
    num
  }
}