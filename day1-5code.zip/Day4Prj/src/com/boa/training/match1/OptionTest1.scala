package com.boa.training.match1

object OptionTest1 {
  def main(args: Array[String]): Unit = {
    val data=Map("Rajiv"->"Developer","Surya"->"Accountant","Priya"->"Architect")
    
    println(getDesignation(data.get("Surya")))
    println(getDesignation(data.get("Arvind")))
    val opt1=data.get("Priya")
    println(opt1)
    
    val opt2=data.get("Amar")
    println(opt2)
    
  }
  
  def getDesignation(s:Option[String])=s match{
    case Some(s)=>s
    case None=>"No such key"
  }
}