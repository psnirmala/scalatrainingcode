package com.boa.training.exceptions

object Calculator {
  import UserDefinedExceptions._
  
  def add(first:Int,second:Int):Int={
    if(first<0||second<0) throw new NegativeNumberException
    val result=first+second
    if(result>1000) throw new IntegerOverflowException;
    
    result
  }
}