package com.boa.training.exceptions

import java.io.FileReader
import java.io.BufferedReader
import java.io.FileNotFoundException
import java.io.IOException

object ExceptionTest1 {
  def main(args: Array[String]): Unit = {
    var reader:FileReader=null
    try {
      reader=new FileReader("c:/test/input.txt")
      val br=new BufferedReader(reader)
      var s=br.readLine()
      while(s!=null){
        println(s)
        s=br.readLine()
      }
      
    } catch {
      case t: FileNotFoundException=>println("no such file")
      case t: IOException=>println("unable to read file")
    }
    finally{
      println("gracefully exiting")
      if(reader!=null){
        reader.close()
      }
    }
  }
}