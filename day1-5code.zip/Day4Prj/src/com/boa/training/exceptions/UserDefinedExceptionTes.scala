package com.boa.training.exceptions



object UserDefinedExceptionTes {
  import UserDefinedExceptions._
  def main(args: Array[String]): Unit = {
    try {
      val first=args(0).toInt
      val second=args(1).toInt
      val sum=Calculator.add(first, second)
      println("sum:"+sum)
    } catch {
      case e: NegativeNumberException => println("Negative numbers are not allowed")
      case e: IntegerOverflowException => println("exceeding the limit")
      case _=>println("run time exception")
    }
    finally{
      println("calculation done")
    }
  }
}