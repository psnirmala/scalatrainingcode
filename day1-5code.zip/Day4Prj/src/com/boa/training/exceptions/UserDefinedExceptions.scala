package com.boa.training.exceptions

object UserDefinedExceptions {
  class IntegerOverflowException extends RuntimeException;
  class NegativeNumberException extends RuntimeException;
}