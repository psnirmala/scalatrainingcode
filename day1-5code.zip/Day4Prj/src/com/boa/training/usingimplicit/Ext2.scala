package com.boa.training.usingimplicit

object Ext2 {
  def main(args: Array[String]): Unit = {
     import Utility._
  
    val x="hello ";
    println(x.appendData("world"))
    println(x.appendData(22))
    println(x.appendData(22.67))
  }
  
}

object Utility{
  
  implicit class StringUtility(s:String){
    def appendData(a:Any)=s+" "+a
  }
}


