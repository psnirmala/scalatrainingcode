package com.boa.training.usingimplicit



object ExtTest {

  implicit class convert(gram:Int){
    def gramsToMilliGrams=gram*1000
  }
  
  def main(args: Array[String]): Unit = {
    val x=80;
    val milliGrms=x.gramsToMilliGrams
    println(milliGrms)
  }
}