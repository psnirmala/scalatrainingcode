package com.boa.training.usingimplicit

object ParamValueInjection {
 
  def test(implicit a:Int){
    println("invoking test with "+a)
  }
  def next(implicit s:String){
   
    println("invoking next with "+s)
  }
  def length(implicit x:String)=x.length()
  def main(args: Array[String]): Unit = {
    implicit val x=20
     implicit val y="hello"
     test
     next
     println(length)
  }
}