package com.boa.training.usingimplicit

class A{
  def method1(){
    println("method1 of A")
  }
}

class B{
  def method2(){
    println("method2 of B")
  }
}
object ConversionTest2 {
  implicit def getBFromA(a:A):B={
    println("invoking implicit method getBFromA")
    new B()
  }
  implicit def getAFromB(b:B):A={
    println("invoking implicit method getAFromB")
    new A()
  }
  def main(args: Array[String]): Unit = {
    val a=new A()
    val b=new B()
    a.method1()
    b.method2()
    
    a.method2()
    
    b.method1()
  }
  
}