package com.boa.training.usingimplicit
case class Person(name:String,age:Int){
  override def toString="Person[name="+name+",age="+age+"]"
}
object CoversionTest1 {
 implicit def func1(a:Int)="value is "+a
 implicit def func2(s:String)=s.toInt
 implicit def func3(p:Person)=p.name
 implicit def func4(p:Person)=p.age
  def main(args: Array[String]): Unit = {
    val x=24
    val a:String=x
    println(a)
    
    val y:Int="55"
    println(y)
    val p=Person("Deva",34)
    val z:Int=p
    println(z)
    val s:String=p
    println(s)
    
    
  }
}