package com.boa.training.usingimplicit


object ETest extends App{

    import Utility._
  
    val x="hello ";
    println(x.appendData("world"))
    println(x.appendData(22))
    println(x.appendData(22.67))
  
}