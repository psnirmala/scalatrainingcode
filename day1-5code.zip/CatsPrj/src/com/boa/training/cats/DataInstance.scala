package com.boa.training.cats

object DataInstance {
  implicit def stringData:Data[String]=(d:String)=>"String Data is"+d
  implicit def intData:Data[Int]=(d:Int)=>"Integer Data is "+d
}