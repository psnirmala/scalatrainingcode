package com.boa.training.cats

trait Data[T] {
  def stringFromData(value:T):String
}