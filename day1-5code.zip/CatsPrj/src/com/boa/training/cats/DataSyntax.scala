package com.boa.training.cats

object DataSyntax {
  implicit class DataOps[T](value:T){
    def print(implicit p:Data[T]):String=p.stringFromData(value)
  }
}