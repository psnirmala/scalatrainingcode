package com.boa.training.cats

object DataTest {
  def main(args: Array[String]): Unit = {
    import DataInstance._
    import DataSyntax._
   // val t1="hello".g
  }
}