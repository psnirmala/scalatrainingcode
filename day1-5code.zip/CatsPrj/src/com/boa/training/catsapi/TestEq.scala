package com.boa.training.catsapi

object TestEq extends App{
  
  val userOpt=Option("user")
  val optCompare=userOpt.fold(false)(_=="user")
  println(optCompare)
  
  val userEither=Right("user")
  val eitherComp=userEither.fold(_=>false, _=="user")
  println(eitherComp)
  
  val filtered=List(Option(1),Option(2),None).filter(_.fold(true)(_!=2))
  println(filtered)
}