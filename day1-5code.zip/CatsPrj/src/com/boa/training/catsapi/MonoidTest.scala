package com.boa.training.catsapi

import cats._
import cats.implicits._
object MonoidTest extends App{
  println(1 |+| 2 |+| 6)
  println(Option(3) |+| Option(5) |+| None |+| Option(7))
  
  
  
  def addAll[A](values:List[A])(implicit monoid:Monoid[A]):A=values.reduce(_ |+| _)
  
  println(addAll(List(1,2,3)))
  println(addAll(List(Option(3) , Option(5) , None , Option(7))))
}