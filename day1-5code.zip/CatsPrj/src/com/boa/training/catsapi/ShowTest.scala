package com.boa.training.catsapi
import cats.Show
//import cats.instances.int._

object ShowTest {
def main(args: Array[String]): Unit = {
  val str=Show.apply[Int].show(20)
  println(str)
  println(Show.apply[String].show("hello"))
}  
}