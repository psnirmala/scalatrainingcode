package com.boa.training.catsapi
import cats.Show
import cats.syntax.show._
object ShowWithSyntaxTest {
def main(args: Array[String]): Unit = {
  val str=100.show
  println(str)
  println("hello".show)
  
}  
}