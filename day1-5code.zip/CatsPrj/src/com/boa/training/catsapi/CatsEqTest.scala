package com.boa.training.catsapi
import cats._
import cats.implicits._
object CatsEqTest {
  def main(args: Array[String]): Unit = {
    case class User(id:Int,name:String)
   implicit def userEq:Eq[User]=Eq.instance[User]((u1,u2)=>{
      println("comparing "+u1.id+" with "+u2.id)
      u1.id==u2.id})
  
    
    val user1=User(1,"Rajiv")
    val user2=User(2,"Deva")
    val user3=User(1,"Suresh")
    println(user1===user2)
    println(user3=!=user1)
    
  }
}