package com.boa.training.catsapi

import cats._
import cats.implicits._
object FunctorTest extends App{
  def doMath[F[_]](start:F[Int])(implicit functor:Functor[F]):F[Int]=start.map(n=>n*5)
  
  println(doMath(Option(20)))
  println(doMath(List(3,6,10)))
      
  
}