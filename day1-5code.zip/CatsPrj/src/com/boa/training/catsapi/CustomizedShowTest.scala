package com.boa.training.catsapi
import cats.Show

case class Person(name:String,age:Int)
import cats.syntax.show._
import java.time.LocalDate
import java.time.format.DateTimeFormatter

object CustomizedShowTest {
def main(args: Array[String]): Unit = {
  
  println("hello".show)
  
  implicit def dataShow:Show[LocalDate]=Show.show(d=>d.format(DateTimeFormatter.ISO_LOCAL_DATE))
  println(LocalDate.now().show)

  implicit def personShow:Show[Person]=Show.show(p=>"Name: "+p.name+"\tAge:"+p.age)
  
  val p1=Person("Arvind",33)
  val p2=Person("Deva",23)
  
  println(p1.show)
  println(p2.show)
}  
}