package com.boa.training.catsapi

object OptEitherTest {
  def main(args: Array[String]): Unit = {
    var a:Option[Int]=Some(20)
    println(a)
    println(a.isEmpty)
    a=None
    println(a)
    println(a.isEmpty)
    println(divide(10,5))
    println(divide(10,0))
    divide(10,2) match{
      case Left(s)=>println(s)
      case Right(ans)=>println("Answer:" +ans)
    }
    divide(10,0) match{
      case Left(s)=>println(s)
      case Right(ans)=>println("Answer:" +ans)
    }
  }
  
  
  def divide(a:Int,b:Int):Either[String,Int]={
    if(b==0) Left("can't divide by zero")
    else Right(a/b)
  }
}