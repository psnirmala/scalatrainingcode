package com.boa.training.cats1
trait Printable[T] {
  def print(value:T):String
}
object PrintableInstance {
  implicit def stringPrintable:Printable[String]=(input:String)=>"Data is "+input
  implicit def intPrintable:Printable[Int]=(input:Int)=>"Data Int is "+input
}

object PrintableSyntax {
  implicit class PrintableOps[T](value:T){
      def display(implicit p:Printable[T])=p.print(value)
  }
}
object Main {
   def main(args: Array[String]): Unit = {
    import PrintableSyntax._
    import PrintableInstance._
    
 //   val x="hello"
    
    println("hello".display)
    
    println("hello".display(PrintableInstance.stringPrintable))
    println(23.display)
  }
}