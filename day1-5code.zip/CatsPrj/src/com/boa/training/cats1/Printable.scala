package com.boa.training.cats1

/*trait Printable[T] {
  def print(value:T):String
}*/