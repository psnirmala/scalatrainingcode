package com.boa.training.cats1

/*object PrintableInstance {
  implicit def stringPrintable:Printable[String]=(input:String)=>"Data is "+input
}*/