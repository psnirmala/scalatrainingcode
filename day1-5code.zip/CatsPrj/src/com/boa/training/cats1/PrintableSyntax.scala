package com.boa.training.cats1

/*object PrintableSyntax {
  implicit class PrintableOps[T](value:T){
      def display(implicit p:Printable[T])=p.print(value)
  }
}*/