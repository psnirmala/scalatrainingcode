package com.boa.training.collections
trait Calc{
  def perform(a:Int,b:Int):Int
}

class R extends Calc{
  def perform(a:Int,b:Int):Int=a+b
}
object TraitTest {
  
  def main(args: Array[String]): Unit = {
    printComputation(new R(),4,5)
    printComputation((a,b)=>a*b,10,5)
  }
  
  def printComputation(c:Calc,x:Int,y:Int):Unit={
    println(c.perform(x,y))
  }
  
}