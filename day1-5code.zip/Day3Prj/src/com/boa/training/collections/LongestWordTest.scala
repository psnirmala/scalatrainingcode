package com.boa.training.collections

object LongestWordTest extends App{
  
  val list=List("the cat sat on the mat","the aardvark sat on the sofa")
  val words=list.flatMap(line=>line.split(" "))
  val wordsInUpperCase=words.map(_.toUpperCase())
  val longestWord=wordsInUpperCase.reduce(
      (word1,word2)=>if(word1.length()>word2.length()) word1 else word2)
        
   println(longestWord)      
   
   val longest=list.flatMap(line=>line.split(" ")).map(_.toUpperCase()).reduce(
      (word1,word2)=>{
        println("comparing "+word1+" with "+word2)
        if(word1.length()>word2.length()) word1 else word2
      })
   println(longest)   
   
    println(list.flatMap(_.split(" ")).map(_.toUpperCase())
        .map(a=>(a.length,a)).toMap.max._2) 
}