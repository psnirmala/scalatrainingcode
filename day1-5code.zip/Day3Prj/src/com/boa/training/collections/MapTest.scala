package com.boa.training.collections

object MapTest extends App{
  
  val m=Map("India"->"Delhi","US"->"Washington","UK"->"London")
  val capitalOfIndia=m("India")
  println(capitalOfIndia)
  
  m.keys.iterator.foreach(k=>println("key:"+k+"\tvalue:"+m(k)))
}