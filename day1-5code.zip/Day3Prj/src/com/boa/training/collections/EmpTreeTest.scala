package com.boa.training.collections

import scala.collection.mutable.TreeSet


class Employee(val id:Int,val name:String,val designation:String){
  override def toString:String="Employee[id="+id+",name="+name+",designation="+designation+"]"
  
}
object EmpTreeTest {
  def main(args: Array[String]): Unit = {
    val set:TreeSet[Employee]=TreeSet()((e1,e2)=>e1.id.compareTo(e2.id))
    
    set += new Employee(1555,"Rajiv","Developer")
    set += new Employee(2001,"Arvind","Accountant")
    set += new Employee(1002,"Surya","Developer")
    println(set)
    
  }
}