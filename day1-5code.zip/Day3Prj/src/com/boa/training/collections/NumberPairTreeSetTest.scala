package com.boa.training.collections

import scala.collection.mutable.TreeSet



object NumberPairTreeSetTest extends App {
  
  val set:TreeSet[NumberPair]=
    TreeSet()((n1:NumberPair,n2:NumberPair)=>(n1.first+n1.second).compareTo(n2.first+n2.second))
    set += new NumberPair(10,34)
    set += new NumberPair(12,22)
    set += new NumberPair(11,56)
    set += new NumberPair(22,14)
  
  println(set)
  
  
  
}