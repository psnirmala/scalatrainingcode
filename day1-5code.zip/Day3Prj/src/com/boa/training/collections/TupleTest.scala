package com.boa.training.collections

object TupleTest {
  def main(args: Array[String]): Unit = {
    val t=(23,"Arvind",new Employee(2233,"Akshay","Developer"))
    t.productIterator.foreach(println)
    println(test()._1)
    println(test()._2)
  }
  
  
  def test()=(34,55)
}