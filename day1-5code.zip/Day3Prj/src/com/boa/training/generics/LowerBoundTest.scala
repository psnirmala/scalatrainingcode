package com.boa.training.generics

class Type4[T>:B](a:T){
  override def toString="Type4["+a+"]"
}

object LowerBoundTest {
  def main(args: Array[String]): Unit = {
   
   val type4A=new Type4[A](new A())
    val type4B=new Type4[B](new B())
   //val type4C=new Type4[C](new C())----not allowed because Type4 can take B or super type of B
    
    println(type4A)
    println(type4B)
   
  }
  
}