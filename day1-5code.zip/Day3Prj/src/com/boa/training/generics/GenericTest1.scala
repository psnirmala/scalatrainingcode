package com.boa.training.generics

case class Emp(empno:Int,name:String,designation:String)
{
  override def toString:String="Emp[Employee No="+empno+",name="+name+",designation="+designation+"]"
}
object GenericTest1 extends App {
  val pair1:Pair[Int]=new Pair(23,76)
  val pair2:Pair[String]=new Pair("Hello","World")
  val pair3:Pair[Emp]=new Pair(Emp(2111,"Deva","Accountant"),Emp(3222,"Arvind","Developer"))
  println(pair1)
  println(pair2)
  println(pair3)
}