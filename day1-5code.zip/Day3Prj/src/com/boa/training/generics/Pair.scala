package com.boa.training.generics

class Pair[T](first:T,second:T) {
  override def toString():String="Pair[first="+first+",second="+second+"]";
  
}