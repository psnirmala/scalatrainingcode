package com.boa.training.generics
class Type1[+T](a:T){
  override def toString="Type1["+a+"]"
}

object CovariantTest {
  def main(args: Array[String]): Unit = {
    val type1A=new Type1[A](new A())
    val type1B=new Type1[B](new B())
    val type1C=new Type1[C](new C())
    
    processObject(new A())
    processObject(new B())
    processObject(new C())
    
    processTypeObject(type1A)
    processTypeObject(type1B)
    processTypeObject(type1C)
  }
  
  def processObject(a:A)
  {
    println("processing "+a)
  }
  def processTypeObject(type1:Type1[A])
  {
    println("processing "+type1)
  }
  
  
}