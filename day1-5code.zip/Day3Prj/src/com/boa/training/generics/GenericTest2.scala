package com.boa.training.generics

class A{
override def toString:String="A"
}

class B extends A{
  override def toString:String="B"
}

class C extends B{
  override def toString:String="C"
}
object GenericTest2 extends App {
  val pair1=new Pair[A](new A(),new B())
  val pair2=new Pair[B](new B(),new C())
  println(pair1)
  println(pair2)
}