package com.boa.training.generics
class Type2[-T](a:T){
  override def toString="Type2["+a+"]"
}

object ContravariantTest {
  def main(args: Array[String]): Unit = {
    val type2A=new Type2[A](new A())
    val type2B=new Type2[B](new B())
    val type2C=new Type2[C](new C())
    
   
    
    processType2Object(type2A)
    processType2Object(type2B)
   // processType2Object(type2C) not allowed because Type2[B] and Type2[super type of B]
    //alone are allowed
  }
  
  
  def processType2Object(type2:Type2[B])
  {
    println("processing "+type2)
  }
  
  
}