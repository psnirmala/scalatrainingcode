package com.boa.training.generics

class Type3[T<:B](a:T){
  override def toString="Type3["+a+"]"
}

object UpperBoundTest {
  def main(args: Array[String]): Unit = {
   val type3B=new Type3[B](new B())
   val type3C=new Type3[C](new C())
   //val typeA=new Type3[A](new A()) not allowed because Type3 can be either type of B or subtype of B
  }
  
}