package com.boa.training.slick

import scala.concurrent.Await
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import slick.jdbc.MySQLProfile.api._
object SlickTest extends App {
  case class Employee(name:String,designation:String,id:Int=0)
  
  def testData=Seq(
      Employee("Arvind","Developer"),
      Employee("Surya","Accountant"),
      Employee("Amar","Developer"),
      )
      
    class EmployeeTable(tag:Tag)
    extends Table[Employee](tag,"employee_tbl"){
    def id=column[Int]("id",O.PrimaryKey,O.AutoInc)
    def name=column[String]("name")
    def designation=column[String]("designation")
    def * = (name,designation,id).mapTo[Employee]
  }
  
  val employees=TableQuery[EmployeeTable]
 
  
  val db=Database.forConfig("TestConfig")
   /*println("inserting data")
  Await.result(db.run(employees ++= testData),10 seconds)*/
  
  /*println("selecting data")
   Await.result(db.run(employees.result),10 seconds).foreach(e=>println(
       e.id+"\t"+e.name+"\t"+e.designation))*/
  
  /*println("selecting all developers")
  val developerQuery=employees.filter(_.designation==="Developer")
   Await.result(db.run(developerQuery.result),10 seconds).foreach(e=>println(
       e.id+"\t"+e.name+"\t"+e.designation))*/
  
  println("updating")
  val updateQuery=employees.filter(_.designation==="Developer").map(_.designation)
  
   Await.result(db.run(updateQuery.update("Software Engr")),10 seconds)
}